sender_mail_address = ""
receiver_mail_address = ""

feed_urls = ["http://arxiv.org/rss/cs.SE", "http://arxiv.org/rss/cs.DC"]
